import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class Portfolio extends HttpServlet {
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String message = request.getParameter("message");

        // Simulating saving to a database or sending via email
        System.out.println("Name: " + name);
        System.out.println("Email: " + email);
        System.out.println("Message: " + message);

        // Responding to the user
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println("<h1>Thank you, " + name + ", for your message!</h1>");
        out.println("<p>We will get back to you soon.</p>");
        out.println("<a href='index.html'>Back to Home</a>");
        out.println("</body></html>");
    }
}
